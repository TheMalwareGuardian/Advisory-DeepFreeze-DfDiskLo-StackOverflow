========================================================================================
FARONICS DATA IGLOO README
========================================================================================

This readme explains the system requirements and general installation procedure for  
Data Igloo.

========================================================================================
ABOUT DATA IGLOO 
========================================================================================

Data Igloo was created to work with Deep Freeze. Deep Freeze protects a computer and 
restores it to the original state on reboot. Data Igloo is a utility that allows you 
to redirect User Profiles, Folders, and Registry Keys to a different location on your 
computer and retain data even after a reboot when the computer is protected by 
Deep Freeze.

Data Igloo can also be used independently without installing Deep Freeze. Data Igloo 
provides an easy way to create NTFS Junction Points and NTFS Symbolic Links using a GUI.

========================================================================================
INSTALLATION PROCEDURE
========================================================================================
It is recommended to install Data Igloo as an administrator and follow the process:

1. Double-click Faronics_IGS.exe. Follow the steps presented.

========================================================================================
DATA IGLOO REQUIREMENTS
========================================================================================

- Windows 7, Windows 8.1, Windows 10 version 1909 (32-bit and 64-bit)
- Microsoft .NET 2.0 (SP1) or higher
- Deep Freeze Enterprise or Deep Freeze Standard (6.3 or higher). This is applicable 
only if you are using Deep Freeze with Data Igloo. Data Igloo can be used independently 
without installing Deep Freeze.

========================================================================================
DEEP FREEZE ENTERPRISE SYSTEM REQUIREMENTS
========================================================================================

Refer to the Deep Freeze Enterprise user guide for the list of system requirements to run the Deep Freeze Configuration Administrator and the Enterprise Console.
https://www.faronics.com/document-library

=========================================================================================
SUPPORT
========================================================================================
Every effort has been made to design this software for ease of use and to be 
problem free. Support resources are available at http://support.faronics.com.